/** @jsxImportSource @emotion/react */
import { css } from "@emotion/react";
import * as S from "./Style"
import React from 'react';

function Order(props) {
    return (
        <div>
            
        </div>
    );
}

export default Order;